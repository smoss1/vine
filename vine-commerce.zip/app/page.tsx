import Link from "next/link"
import Image from "next/image"
import { ArrowRight, CheckCircle, Globe, MessageSquare, MousePointerClick } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Testimonials } from "@/components/testimonials"
import { ContactForm } from "@/components/contact-form"
import { StatsSection } from "@/components/stats-section"
import { ServiceGrid } from "@/components/service-grid"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-20 flex items-center justify-between">
        <Link className="flex items-center gap-2" href="#">
          <div className="flex items-center">
            <span className="text-primary font-bold text-xl">VINE</span>
            <span className="text-secondary font-bold text-xl">COMMERCE</span>
          </div>
          <span className="text-xs text-gray-500 hidden sm:inline">creative growth strategy</span>
        </Link>
        <nav className="hidden md:flex gap-6">
          <Link
            className="text-sm font-medium hover:text-secondary hover:underline underline-offset-4"
            href="#services"
          >
            Services
          </Link>
          <Link className="text-sm font-medium hover:text-secondary hover:underline underline-offset-4" href="#about">
            About
          </Link>
          <Link
            className="text-sm font-medium hover:text-secondary hover:underline underline-offset-4"
            href="#testimonials"
          >
            Testimonials
          </Link>
          <Link className="text-sm font-medium hover:text-secondary hover:underline underline-offset-4" href="#contact">
            Contact
          </Link>
        </nav>
        <Button asChild className="hidden md:flex bg-secondary hover:bg-secondary/90">
          <Link href="#contact">Get In Touch</Link>
        </Button>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 bg-white">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 xl:grid-cols-2">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none text-[#2d2d2d]">
                    Discover <span className="text-primary">Vine Commerce</span>
                  </h1>
                  <p className="max-w-[600px] text-gray-600 md:text-xl">
                    Explore our products and services, tailored to meet your needs and exceed your expectations.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button asChild size="lg" className="bg-secondary hover:bg-secondary/90">
                    <Link href="#contact">
                      Get In Touch
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                  <Button variant="outline" size="lg" className="border-primary text-primary hover:bg-primary/10">
                    <Link href="#services">Learn More</Link>
                  </Button>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <Image
                  alt="Digital Marketing Dashboard"
                  className="rounded-lg object-cover shadow-lg"
                  src="/placeholder.svg?height=550&width=550"
                  width={550}
                  height={550}
                />
              </div>
            </div>
          </div>
        </section>

        <StatsSection />

        <section id="services" className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary">Services</div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-[#2d2d2d]">
                  Our Digital Marketing Solutions
                </h2>
                <p className="max-w-[900px] text-gray-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Comprehensive strategies tailored to your business goals and target audience
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-8">
              <Card className="border-none shadow-md">
                <CardHeader className="flex flex-row items-center gap-4 pb-2">
                  <div className="rounded-full bg-primary/10 p-2">
                    <Globe className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-xl">SEO Optimization</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm text-gray-600">
                    Improve your search engine rankings and drive organic traffic to your website with our data-driven
                    SEO strategies.
                  </CardDescription>
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-primary" />
                      <span className="text-sm">Keyword Research</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-primary" />
                      <span className="text-sm">On-Page Optimization</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-primary" />
                      <span className="text-sm">Link Building</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-none shadow-md">
                <CardHeader className="flex flex-row items-center gap-4 pb-2">
                  <div className="rounded-full bg-primary/10 p-2">
                    <MousePointerClick className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-xl">PPC Advertising</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm text-gray-600">
                    Maximize your ROI with targeted pay-per-click campaigns across Google, Facebook, and other
                    platforms.
                  </CardDescription>
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-primary" />
                      <span className="text-sm">Campaign Strategy</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-primary" />
                      <span className="text-sm">Ad Creation</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-primary" />
                      <span className="text-sm">Performance Tracking</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-none shadow-md">
                <CardHeader className="flex flex-row items-center gap-4 pb-2">
                  <div className="rounded-full bg-primary/10 p-2">
                    <MessageSquare className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-xl">Social Media</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm text-gray-600">
                    Build a strong social presence and engage with your audience through strategic content and community
                    management.
                  </CardDescription>
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-primary" />
                      <span className="text-sm">Content Creation</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-primary" />
                      <span className="text-sm">Community Management</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-primary" />
                      <span className="text-sm">Growth Strategies</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <ServiceGrid />

        <section id="about" className="w-full py-12 md:py-24 lg:py-32 bg-white">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary">About Us</div>
                  <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-[#2d2d2d]">
                    Creative Growth Strategy
                  </h2>
                  <p className="max-w-[600px] text-gray-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                    At Vine Commerce, we're passionate about helping businesses thrive in the digital landscape. With
                    over a decade of experience, our team of experts combines creativity with data-driven strategies to
                    deliver exceptional results.
                  </p>
                </div>
                <Tabs defaultValue="mission" className="w-full">
                  <TabsList className="grid w-full grid-cols-3 bg-primary/10">
                    <TabsTrigger
                      value="mission"
                      className="data-[state=active]:bg-primary data-[state=active]:text-white"
                    >
                      Mission
                    </TabsTrigger>
                    <TabsTrigger
                      value="vision"
                      className="data-[state=active]:bg-primary data-[state=active]:text-white"
                    >
                      Vision
                    </TabsTrigger>
                    <TabsTrigger
                      value="values"
                      className="data-[state=active]:bg-primary data-[state=active]:text-white"
                    >
                      Values
                    </TabsTrigger>
                  </TabsList>
                  <TabsContent value="mission" className="p-4 border rounded-md mt-2">
                    <p className="text-gray-600">
                      Our mission is to empower businesses with innovative digital marketing solutions that drive
                      growth, enhance brand visibility, and create meaningful connections with their audience.
                    </p>
                  </TabsContent>
                  <TabsContent value="vision" className="p-4 border rounded-md mt-2">
                    <p className="text-gray-600">
                      We envision a world where businesses of all sizes can harness the power of digital marketing to
                      achieve their full potential and make a lasting impact in their industries.
                    </p>
                  </TabsContent>
                  <TabsContent value="values" className="p-4 border rounded-md mt-2">
                    <ul className="space-y-2 text-gray-600">
                      <li className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-primary" />
                        <span>Innovation: We embrace new technologies and approaches</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-primary" />
                        <span>Integrity: We operate with honesty and transparency</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-primary" />
                        <span>Results: We're committed to delivering measurable outcomes</span>
                      </li>
                    </ul>
                  </TabsContent>
                </Tabs>
              </div>
              <div className="flex items-center justify-center">
                <Image
                  alt="Vine Commerce Team"
                  className="rounded-lg object-cover shadow-lg"
                  src="/placeholder.svg?height=400&width=600"
                  width={600}
                  height={400}
                />
              </div>
            </div>
          </div>
        </section>

        <Testimonials />

        <section id="contact" className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary">Contact Us</div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-[#2d2d2d]">
                  Let's Grow Your Business Together
                </h2>
                <p className="max-w-[600px] text-gray-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Ready to take your digital marketing to the next level? Get in touch with our team today.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 lg:grid-cols-2 mt-8">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-[#2d2d2d]">Our Office</h3>
                  <p className="text-gray-600">
                    123 Marketing Street
                    <br />
                    Digital City, DC 10101
                    <br />
                    United States
                  </p>
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-[#2d2d2d]">Contact Information</h3>
                  <p className="text-gray-600">
                    Email: info@vinecommerce.com
                    <br />
                    Phone: (555) 123-4567
                  </p>
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-[#2d2d2d]">Business Hours</h3>
                  <p className="text-gray-600">
                    Monday - Friday: 9:00 AM - 5:00 PM
                    <br />
                    Saturday - Sunday: Closed
                  </p>
                </div>
              </div>
              <ContactForm />
            </div>
          </div>
        </section>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
        <p className="text-xs text-gray-500">© 2025 Vine Commerce. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link className="text-xs hover:underline underline-offset-4 text-gray-500 hover:text-secondary" href="#">
            Terms of Service
          </Link>
          <Link className="text-xs hover:underline underline-offset-4 text-gray-500 hover:text-secondary" href="#">
            Privacy
          </Link>
          <Link className="text-xs hover:underline underline-offset-4 text-gray-500 hover:text-secondary" href="#">
            Cookies
          </Link>
        </nav>
      </footer>
    </div>
  )
}

