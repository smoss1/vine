import Image from "next/image"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export function ServiceGrid() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-white">
      <div className="container px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-4">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-[#2d2d2d]">
              Discover <span className="text-primary">Vine Commerce</span>
            </h2>
            <p className="text-gray-600 md:text-xl">
              Explore our products and services, tailored to meet your needs and exceed your expectations.
            </p>
            <Button asChild className="bg-secondary hover:bg-secondary/90">
              <Link href="#contact">Get In Touch</Link>
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col gap-4">
              <div className="relative overflow-hidden rounded-lg shadow-lg">
                <Image
                  src="/placeholder.svg?height=250&width=250"
                  alt="Strategy"
                  width={250}
                  height={250}
                  className="object-cover w-full h-full"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                  <p className="text-white font-medium">Strategy</p>
                </div>
              </div>
              <div className="relative overflow-hidden rounded-lg shadow-lg">
                <Image
                  src="/placeholder.svg?height=250&width=250"
                  alt="Reporting"
                  width={250}
                  height={250}
                  className="object-cover w-full h-full"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                  <p className="text-white font-medium">Reporting</p>
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-4">
              <div className="relative overflow-hidden rounded-lg shadow-lg">
                <Image
                  src="/placeholder.svg?height=250&width=250"
                  alt="Development"
                  width={250}
                  height={250}
                  className="object-cover w-full h-full"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                  <p className="text-white font-medium">Development</p>
                </div>
              </div>
              <div className="relative overflow-hidden rounded-lg shadow-lg">
                <Image
                  src="/placeholder.svg?height=250&width=250"
                  alt="Analysis"
                  width={250}
                  height={250}
                  className="object-cover w-full h-full"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                  <p className="text-white font-medium">Analysis</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

