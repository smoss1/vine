"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { CheckCircle } from "lucide-react"

export function ContactForm() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsSubmitting(false)
    setIsSubmitted(true)
  }

  if (isSubmitted) {
    return (
      <div className="flex flex-col items-center justify-center space-y-4 border rounded-lg p-8 h-full bg-white shadow-md">
        <CheckCircle className="h-16 w-16 text-green-500" />
        <h3 className="text-2xl font-bold text-[#2d2d2d]">Message Sent!</h3>
        <p className="text-center text-gray-600">
          Thank you for contacting Vine Commerce. We'll get back to you within 24 hours.
        </p>
        <Button onClick={() => setIsSubmitted(false)} className="bg-secondary hover:bg-secondary/90">
          Send Another Message
        </Button>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 border rounded-lg p-6 bg-white shadow-md">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="first-name">First name</Label>
          <Input
            id="first-name"
            placeholder="John"
            required
            className="border-gray-300 focus:border-primary focus:ring-primary"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="last-name">Last name</Label>
          <Input
            id="last-name"
            placeholder="Doe"
            required
            className="border-gray-300 focus:border-primary focus:ring-primary"
          />
        </div>
      </div>
      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          placeholder="john.doe@example.com"
          type="email"
          required
          className="border-gray-300 focus:border-primary focus:ring-primary"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="company">Company</Label>
        <Input
          id="company"
          placeholder="Your Company"
          className="border-gray-300 focus:border-primary focus:ring-primary"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="message">Message</Label>
        <Textarea
          className="min-h-[120px] border-gray-300 focus:border-primary focus:ring-primary"
          id="message"
          placeholder="Tell us about your project and goals..."
          required
        />
      </div>
      <Button className="w-full bg-secondary hover:bg-secondary/90" type="submit" disabled={isSubmitting}>
        {isSubmitting ? "Sending..." : "Get In Touch"}
      </Button>
    </form>
  )
}

