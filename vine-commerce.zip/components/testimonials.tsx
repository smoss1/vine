import { Card, CardContent } from "@/components/ui/card"
import { Quote } from "lucide-react"

export function Testimonials() {
  return (
    <section id="testimonials" className="w-full py-12 md:py-24 lg:py-32 bg-white">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary">Testimonials</div>
            <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-[#2d2d2d]">What Our Clients Say</h2>
            <p className="max-w-[900px] text-gray-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Don't just take our word for it. Here's what our clients have to say about working with Vine Commerce.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-8">
          <Card className="border-none shadow-md">
            <CardContent className="p-6">
              <Quote className="h-8 w-8 text-primary mb-4" />
              <p className="text-gray-600 mb-4">
                "Vine Commerce transformed our digital strategy. Their SEO expertise helped us rank for competitive
                keywords, and our organic traffic has increased by 150% in just six months."
              </p>
              <div className="flex items-center gap-4">
                <div className="rounded-full bg-primary/10 h-12 w-12 flex items-center justify-center text-primary font-bold">
                  SJ
                </div>
                <div>
                  <p className="font-medium text-[#2d2d2d]">Sarah Johnson</p>
                  <p className="text-sm text-gray-500">CEO, TechStart Inc.</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-none shadow-md">
            <CardContent className="p-6">
              <Quote className="h-8 w-8 text-primary mb-4" />
              <p className="text-gray-600 mb-4">
                "The PPC campaigns managed by Vine Commerce delivered an ROI of 300%. Their data-driven approach and
                continuous optimization made all the difference for our e-commerce business."
              </p>
              <div className="flex items-center gap-4">
                <div className="rounded-full bg-primary/10 h-12 w-12 flex items-center justify-center text-primary font-bold">
                  MC
                </div>
                <div>
                  <p className="font-medium text-[#2d2d2d]">Michael Chen</p>
                  <p className="text-sm text-gray-500">Marketing Director, ShopEasy</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-none shadow-md">
            <CardContent className="p-6">
              <Quote className="h-8 w-8 text-primary mb-4" />
              <p className="text-gray-600 mb-4">
                "Working with Vine Commerce on our social media strategy has been a game-changer. Our engagement rates
                have doubled, and we're seeing real conversions from our social channels."
              </p>
              <div className="flex items-center gap-4">
                <div className="rounded-full bg-primary/10 h-12 w-12 flex items-center justify-center text-primary font-bold">
                  ER
                </div>
                <div>
                  <p className="font-medium text-[#2d2d2d]">Emily Rodriguez</p>
                  <p className="text-sm text-gray-500">Social Media Manager, Lifestyle Brands</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}

